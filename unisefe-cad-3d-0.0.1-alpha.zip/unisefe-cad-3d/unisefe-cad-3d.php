<?php
/**
 * Plugin Name: UNISEFE CAD 3D
 * Description: Lightweight WordPress wrapper for the self-contained UNISEFE CAD 3D application.
 * Version: 0.0.1-alpha
 * Author: ITALFABER / UNISEFE
 * License: MIT
 */

if (!defined('ABSPATH')) {
    exit;
}

function unisefe_cad_3d_shortcode($atts = array()) {
    $atts = shortcode_atts(array(
        'height' => '85vh',
    ), $atts, 'unisefe_cad_3d');

    $height = preg_replace('/[^0-9a-zA-Z.%()\-+\s]/', '', (string) $atts['height']);
    if ($height === '') {
        $height = '85vh';
    }

    $src = plugins_url('app/unisefe-cad-3d.html', __FILE__);

    return sprintf(
        '<iframe class="unisefe-cad-3d-frame" src="%1$s" title="UNISEFE CAD 3D" loading="lazy" style="display:block;width:100%%;height:%2$s;border:0;background:#fff;" allowfullscreen></iframe>',
        esc_url($src),
        esc_attr($height)
    );
}
add_shortcode('unisefe_cad_3d', 'unisefe_cad_3d_shortcode');
add_shortcode('riki_cad_3d', 'unisefe_cad_3d_shortcode');
