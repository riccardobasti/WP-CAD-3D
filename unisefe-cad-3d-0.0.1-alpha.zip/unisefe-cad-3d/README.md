# UNISEFE CAD 3D

**Plugin version:** 0.0.1 Alpha  
**CAD engine:** UNISEFE CAD 3D v0.0.3 Alpha  
**Platform:** WordPress  
**Type:** Browser-based 3D CAD  
**Interface:** HTML + SVG + JavaScript  
**License:** MIT

## Overview

UNISEFE CAD 3D is a lightweight browser-based 3D CAD application packaged as a WordPress plugin.

The CAD engine remains self-contained. WordPress acts only as a thin host layer, loading the original application without restructuring its internal CAD logic.

The application follows a clear architectural contract:

- static HTML defines the user interface;
- RIKI Space owns canonical BYTE/BIT state and permanent CHAINS;
- JavaScript is the thin runtime for interpretation, input, projection and I/O;
- SVG is only the projection of canonical geometry, not the canonical model;
- POINT and GUIDE_POINT close through Delta Zero before geometry is committed.

## Main Features

### 2D / 3D drawing environment

The current engine includes:

- Select
- Line
- Dashed line
- Dash-dot line
- Circle
- Arc
- Text

### Dimensioning

- 3D linear dimension
- Angular dimension
- Progressive aligned dimension

### Editing

- Undo
- Move
- Copy
- Trim
- Extend
- Fillet
- Mirror
- Rotate
- Delete

### 3D modeling

- Extrude
- Revolve

### 3D view

- Orbit
- Fit
- Zoom
- Pan
- Camera yaw
- Camera tilt
- Workplane support

### Project tools

- Open
- Save
- Print
- Save as PDF through browser printing

## Native 3D State

The RIKI canonical state includes dedicated 3D values such as:

```text
CAMERA_YAW
CAMERA_TILT
WORKPLANE
WORK_Z
POINT_X
POINT_Y
POINT_Z
SNAP_X
SNAP_Y
SNAP_Z
```

The HUD exposes X, Y and Z coordinates directly in the CAD interface.

## RIKI Space

The application contains a canonical RIKI Space with persistent BYTE/BIT state.

Examples:

```text
SPACE
CAD
TOOL
SNAP
VIEW_X
VIEW_Y
VIEW_SCALE
CAMERA_YAW
CAMERA_TILT
WORKPLANE
WORK_Z
POINT
SNAP_POINT
DIMENSION
```

Each logical state is represented through the RIKI model:

```text
NAME
VALUE
BIT
```

The persistent drawing region is stored inside:

```html
<riki-region name="DRAWING" permanent="true"></riki-region>
```

Permanent mathematical relations are stored in:

```html
<riki-region name="CHAINS" permanent="true">
```

## Delta Zero / BIT

The interface exposes the RIKI closure state directly:

```text
POINT · Δ 0 · BIT 1
```

The core idea is that geometry is committed only after the relevant input relation is closed according to the current RIKI state.

## Geometric Relations

The engine contains persistent mathematical chains for geometric operations including:

- distance
- midpoint
- line intersection
- perpendicular projection
- tangent points
- line-circle intersection
- circle-circle intersection
- rotation
- mirror transformation
- arc geometry
- dimension geometry
- fit and zoom relations

## Interface

The CAD interface includes:

- top CAD toolbar
- native SVG drawing surface
- XYZ HUD
- command status
- selection status
- entity counter
- sliding properties panel

The properties panel currently exposes:

- line color
- line width
- snap spacing
- midpoint snap
- quadrant snap
- intersection snap
- perpendicular snap
- tangent snap
- text size
- dimension decimals

## Responsive Design

The interface includes layouts for:

- desktop
- tablet
- mobile
- small mobile screens
- landscape mobile devices

The properties panel becomes a slide-out drawer on reduced-width layouts.

## WordPress Integration

WordPress only hosts the CAD application.

The CAD remains isolated inside its own iframe so that theme CSS and JavaScript do not interfere with the application.

### Installation

In WordPress:

```text
Plugins
→ Add New Plugin
→ Upload Plugin
```

Upload the plugin ZIP and activate it.

### Shortcode

```text
[unisefe_cad_3d]
```

Alias:

```text
[riki_cad_3d]
```

### Custom height

```text
[unisefe_cad_3d height="900px"]
```

or:

```text
[unisefe_cad_3d height="85vh"]
```

## Architecture

```text
WordPress
    │
    ▼
Plugin wrapper
    │
    ▼
UNISEFE CAD 3D
    │
    ├── Static HTML interface
    ├── SVG projection
    ├── CAD commands
    ├── RIKI Space
    ├── BYTE / BIT state
    ├── Permanent CHAINS
    ├── 3D camera state
    └── Persistent drawing region
```

## Design Principle

> WordPress hosts the CAD. WordPress does not become the CAD.

This keeps the CAD engine portable, inspectable and independent from the active WordPress theme.

## Portability

The same CAD engine can potentially be hosted in:

- WordPress
- static HTML
- GitHub Pages
- local browser environments
- other CMS platforms
- standalone web applications

Only the external wrapper needs to change.

## Current Status

**Alpha**

The project is under active development. Current development areas include:

- 3D geometry refinement
- extrusion and revolution behavior
- workplane handling
- orbit and projection behavior
- snap reliability in 3D
- geometric closure through Delta Zero
- import/export improvements
- future structural integration

## Technical Stack

```text
HTML5
CSS
JavaScript
SVG
WordPress / PHP wrapper
RIKI Space
```

## Repository Structure

```text
unisefe-cad-3d/
│
├── unisefe-cad-3d.php
├── app/
│   └── unisefe-cad-3d.html
│
└── README.md
```

## Version

```text
UNISEFE CAD 3D
WordPress Plugin 0.0.1 Alpha
CAD Engine 0.0.3 Alpha
```

## Author

**ITALFABER / UNISEFE**

https://italfaber.com/

## License

MIT License.

The software may be used, studied, modified and redistributed according to the terms of the MIT License.

## Experimental Project

UNISEFE CAD 3D is experimental Alpha software intended for testing, research and continued development.
